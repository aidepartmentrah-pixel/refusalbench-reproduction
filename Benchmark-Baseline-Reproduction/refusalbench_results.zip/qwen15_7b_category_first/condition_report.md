# Condition report: `category_first` (Qwen1.5-7B-Chat, RefusalBench-NQ subset)

*Generated automatically. Compare conditions with `scripts/compare_conditions.py`. This is not a paper reproduction.*

- Examples generated 800, scored 0, unjudged 800, empty replies 0
- Reply format after extraction: {'no_code': 789, 'clean_code': 11} (clean code rate 1.4%)
- Extraction flags: {}
- Evidence states: {}
- Target: `Qwen/Qwen1.5-7B-Chat` 4bit, temperature 1.0, top_p 1.0, seed 0; judge `gemini-3.5-flash-lite`; prompt hash `c0008c7504b3`

## Results
| metric | value |
|---|---:|
| answerable / unanswerable | 0 / 0 |
| answer accuracy | n/a |
| refusal accuracy | n/a |
| false refusal rate | n/a |
| missed refusal rate | n/a |
| refusal detection F1 | n/a |
| calibrated refusal score | n/a |

### By uncertainty type
| group | n | answer acc | refusal acc | false refusal | missed refusal | detection F1 |
|---|---:|---:|---:|---:|---:|---:|

### By intensity
| group | n | answer acc | refusal acc | false refusal | missed refusal | detection F1 |
|---|---:|---:|---:|---:|---:|---:|
