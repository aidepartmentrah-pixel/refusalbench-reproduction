# Condition report: `format_only` (Qwen1.5-7B-Chat, RefusalBench-NQ subset)

*Generated automatically. Compare conditions with `scripts/compare_conditions.py`. This is not a paper reproduction.*

- Examples generated 800, scored 669, unjudged 131, empty replies 0
- Reply format after extraction: {'clean_code': 208, 'no_code': 579, 'unknown_code': 13} (clean code rate 26.0%)
- Extraction flags: {'no_final_line': 81}
- Evidence states: {None: 669}
- Target: `Qwen/Qwen1.5-7B-Chat` 4bit, temperature 1.0, top_p 1.0, seed 0; judge `gemini-3.5-flash-lite`; prompt hash `c0008c7504b3`

## Results
| metric | value |
|---|---:|
| answerable / unanswerable | 227 / 442 |
| answer accuracy | 0.740 |
| refusal accuracy | 0.068 |
| false refusal rate | 0.088 |
| missed refusal rate | 0.534 |
| refusal detection F1 | 0.617 |
| calibrated refusal score | 0.404 |

### By uncertainty type
| group | n | answer acc | refusal acc | false refusal | missed refusal | detection F1 |
|---|---:|---:|---:|---:|---:|---:|
| P-Ambiguity | 90 | 0.882 | 0.018 | 0.059 | 0.750 | 0.389 |
| P-Contradiction | 118 | 0.795 | 0.000 | 0.026 | 0.823 | 0.298 |
| P-EpistemicMismatch | 108 | 0.794 | 0.014 | 0.029 | 0.297 | 0.819 |
| P-FalsePremise | 121 | 0.548 | 0.114 | 0.262 | 0.304 | 0.759 |
| P-GranularityMismatch | 109 | 0.649 | 0.014 | 0.108 | 0.278 | 0.813 |
| P-MissingInfo | 123 | 0.805 | 0.220 | 0.024 | 0.768 | 0.373 |

### By intensity
| group | n | answer acc | refusal acc | false refusal | missed refusal | detection F1 |
|---|---:|---:|---:|---:|---:|---:|
| HIGH | 226 | n/a | 0.062 | n/a | 0.478 | 0.686 |
| LOW | 227 | 0.740 | n/a | 0.088 | n/a | n/a |
| MEDIUM | 216 | n/a | 0.074 | n/a | 0.593 | 0.579 |
